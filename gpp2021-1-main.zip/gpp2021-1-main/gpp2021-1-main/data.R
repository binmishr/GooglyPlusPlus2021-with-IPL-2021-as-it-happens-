load("./ipl/iplBattingBowlingDetails/IPLBatsmen.RData")
IPLBatsmen <-iplBatsmen
cat("lengthbatsIPL=",length(IPLBatsmen),"\n")

load("./ipl/iplBattingBowlingDetails/IPLBowlers.RData")
IPLBowlers <-iplBowlers

a <-list.files("./ipl/iplMatches/")
IPLMatches <- gsub(".RData","",a)
cat("length=",length(IPLMatches),"\n")

a1 <-list.files("./ipl/iplMatches2Teams/")
IPLMatches2Teams <- gsub(".RData","",a1)

a2 <-list.files("./ipl/iplAllMatchesAllTeams/")
IPLTeamsAll <- gsub(".RData","",a2)

# IPL Team names
IPLTeamNames <- list("Chennai Super Kings","Deccan Chargers","Delhi Capitals", "Delhi Daredevils",
                     "Kings XI Punjab","Punjab Kings", 'Kochi Tuskers Kerala',"Kolkata Knight Riders",
                     "Mumbai Indians", "Pune Warriors","Rajasthan Royals",
                     "Royal Challengers Bangalore","Sunrisers Hyderabad","Gujarat Lions",
                     "Rising Pune Supergiants")

############################################

# ## BBL
load("./bbl/bblBattingBowlingDetails/BBLbatsmen.RData")
BBLBatsmen <-bblBatsmen
cat("lengthbatsBBL=",length(BBLBatsmen),"\n")

load("./bbl/bblBattingBowlingDetails/BBLbowlers.RData")
BBLBowlers <-bblBowlers

a <-list.files("./bbl/bblMatches/")
BBLMatches <- gsub(".RData","",a)
cat("length BBL match=",length(BBLMatches),"\n")

a1 <-list.files("./bbl/bblMatches2Teams/")
BBLMatches2Teams <- gsub(".RData","",a1)

a2 <-list.files("./bbl/bblAllMatchesAllTeams/")
BBLTeamsAll <- gsub(".RData","",a2)

# BBL Team names
BBLTeamNames <- list("Adelaide Strikers", "Brisbane Heat", "Hobart Hurricanes",
                     "Melbourne Renegades", "Melbourne Stars", "Perth Scorchers", "Sydney Sixers",
                     "Sydney Thunder")


# ##############################################
# #NTB
load("./ntb/ntbBattingBowlingDetails/NTBbatsmen.RData")
NTBBatsmen <-ntbBatsmen
cat("lengthbatsNTB=",length(NTBBatsmen),"\n")

load("./ntb/ntbBattingBowlingDetails/NTBbowlers.RData")
NTBBowlers <-ntbBowlers

a <-list.files("./ntb/ntbMatches/")
NTBMatches <- gsub(".RData","",a)
cat("length NTB match=",length(NTBMatches),"\n")

a1 <-list.files("./ntb/ntbMatches2Teams/")
NTBMatches2Teams <- gsub(".RData","",a1)

a2 <-list.files("./ntb/ntbAllMatchesAllTeams/")
NTBTeamsAll <- gsub(".RData","",a2)

# NTB Team names
NTBTeamNames <- list("Birmingham Bears","Derbyshire", "Durham", "Essex", "Glamorgan",
                     "Gloucestershire", "Hampshire", "Kent","Lancashire",
                     "Leicestershire", "Middlesex","Northamptonshire",
                     "Nottinghamshire","Somerset","Surrey","Sussex","Warwickshire",
                     "Worcestershire","Yorkshire")


# #########################################################
#PSL

load("./psl/pslBattingBowlingDetails/PSLbatsmen.RData")
PSLBatsmen <-pslBatsmen
cat("lengthbatsPSL=",length(PSLBatsmen),"\n")

load("./psl/pslBattingBowlingDetails/PSLbowlers.RData")
PSLBowlers <-pslBowlers

a <-list.files("./psl/pslMatches/")
PSLMatches <- gsub(".RData","",a)
cat("length PSL match=",length(PSLMatches),"\n")

a1 <-list.files("./psl/pslMatches2Teams/")
PSLMatches2Teams <- gsub(".RData","",a1)

a2 <-list.files("./psl/pslAllMatchesAllTeams/")
PSLTeamsAll <- gsub(".RData","",a2)

# PSL Team names
PSLTeamNames <- list("Islamabad United","Karachi Kings", "Lahore Qalandars", "Multan Sultans",
                     "Peshawar Zalmi", "Quetta Gladiators")


# ############################################################
# #WBB
# ## WBB
load("./wbb/wbbBattingBowlingDetails/WBBbatsmen.RData")
WBBBatsmen <-wbbBatsmen
cat("lengthbatsWBB=",length(WBBBatsmen),"\n")

load("./wbb/wbbBattingBowlingDetails/WBBbowlers.RData")
WBBBowlers <-wbbBowlers

a <-list.files("./wbb/wbbMatches/")
WBBMatches <- gsub(".RData","",a)
cat("length WBB match=",length(WBBMatches),"\n")

a1 <-list.files("./wbb/wbbMatches2Teams/")
WBBMatches2Teams <- gsub(".RData","",a1)

a2 <-list.files("./wbb/wbbAllMatchesAllTeams/")
WBBTeamsAll <- gsub(".RData","",a2)

# WBB Team names
WBBTeamNames <- list("Adelaide Strikers", "Brisbane Heat", "Hobart Hurricanes",
                     "Melbourne Renegades", "Melbourne Stars", "Perth Scorchers", "Sydney Sixers",
                     "Sydney Thunder")

#########################################
# CPL
load("./cpl/cplBattingBowlingDetails/CPLbatsmen.RData")
CPLBatsmen <-cplBatsmen
cat("lengthbatsCPL=",length(CPLBatsmen),"\n")

load("./cpl/cplBattingBowlingDetails/CPLbowlers.RData")
CPLBowlers <-cplBowlers

a <-list.files("./cpl/cplMatches/")
CPLMatches <- gsub(".RData","",a)
cat("length=",length(CPLMatches),"\n")

a1 <-list.files("./cpl/cplMatches2Teams/")
CPLMatches2Teams <- gsub(".RData","",a1)

a2 <-list.files("./cpl/cplAllMatchesAllTeams/")
CPLTeamsAll <- gsub(".RData","",a2)

# CPL Team names
CPLTeamNames <- list("Antigua Hawksbills","Barbados Tridents","Guyana Amazon Warriors","Jamaica Tallawahs",
                       "St Kitts and Nevis Patriots","St Lucia Zouks","Trinbago Knight Riders")


# ############################################
#ODI Men

# load("./odi/odiBattingBowlingDetails/ODIMbatsmen.RData")
# ODIMBatsmen <-odimBatsmen
# cat("lengthbatsm=",length(ODIMBatsmen),"\n")
#
# load("./odi/odiBattingBowlingDetails/ODIMbowlers.RData")
# ODIMBowlers <-odimBowlers
#
# a <-list.files("./odi/odiMenMatches/")
# ODIMMatches <- gsub(".RData","",a)
# cat("length=",length(ODIMMatches),"\n")
#
# a1 <-list.files("./odi/odiMatches2Teams/")
# ODIMMatches2Teams <- gsub(".RData","",a1)
#
# a2 <-list.files("./odi/odiAllMatchesAllTeams/")
# ODIMTeamsAll <- gsub(".RData","",a2)
#
# # odi Men Team names
# ODIMTeamNames <- list("Australia","India","Pakistan","West Indies", 'Sri Lanka',
#                       "England", "Bangladesh","Netherlands","Scotland", "Afghanistan",
#                       "Zimbabwe","Ireland","New Zealand","South Africa","Canada",
#                       "Bermuda","Kenya","Hong Kong","Nepal","Oman","Papua New Guinea",
#                       "United Arab Emirates","Namibia",
#                       "United States of America")

# ############################################
#ODI Women

# load("./odi/odiWomenBattingBowlingDetails/ODIWbatsmen.RData")
# ODIWBatsmen <-odiwBatsmen
# cat("lengthbatsm=",length(ODIWBatsmen),"\n")
#
# load("./odi/odiWomenBattingBowlingDetails/ODIWbowlers.RData")
# ODIWBowlers <-odiwBowlers
#
# a <-list.files("./odi/odiWomenMatches/")
# ODIWMatches <- gsub(".RData","",a)
# cat("length=",length(ODIWMatches),"\n")
#
# a1 <-list.files("./odi/odiWomenMatches2Teams/")
# ODIWMatches2Teams <- gsub(".RData","",a1)
#
# a2 <-list.files("./odi/odiWomenAllMatchesAllTeams/")
# ODIWTeamsAll <- gsub(".RData","",a2)
# cat("All ODIW teams=",ODIWTeamsAll)
#
# # odi Men Team names
# ODIWTeamNames <- list("Australia","India","Pakistan","West Indies", 'Sri Lanka',
#                       "England", "Bangladesh",
#                       "Ireland","New Zealand","South Africa")



